webpackHotUpdate_N_E("pages/index",{

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/next/dist/compiled/postcss-loader/cjs.js?!./node_modules/resolve-url-loader/index.js?!./node_modules/sass-loader/dist/cjs.js?!./components/aboutUs.module.scss":
/*!***************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--5-oneOf-3-1!./node_modules/next/dist/compiled/postcss-loader/cjs.js??ref--5-oneOf-3-2!./node_modules/resolve-url-loader??ref--5-oneOf-3-3!./node_modules/sass-loader/dist/cjs.js??ref--5-oneOf-3-4!./components/aboutUs.module.scss ***!
  \***************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(true);
// Module
___CSS_LOADER_EXPORT___.push([module.i, ".aboutUs_AboutUs__2aY9A {\n  width: 100%;\n  overflow: hidden;\n  filter: grayscale(1);\n}\n\n@media (min-width: 768px) {\n  .aboutUs_AboutUs__2aY9A img {\n    min-width: 584px;\n    min-height: 470px;\n  }\n}", "",{"version":3,"sources":["webpack://aboutUs.module.scss"],"names":[],"mappings":"AAAA;EACI,WAAA;EACA,gBAAA;EACA,oBAAA;AACJ;;AACA;EACI;IACI,gBAAA;IACA,iBAAA;EAEN;AACF","sourcesContent":[".AboutUs {\r\n    width: 100%;\r\n    overflow: hidden;\r\n    filter: grayscale(1);\r\n}\r\n@media(min-width:768px) {\r\n    .AboutUs img {\r\n        min-width: 584px;\r\n        min-height: 470px;\r\n    }\r\n}\r\n"],"sourceRoot":""}]);
// Exports
___CSS_LOADER_EXPORT___.locals = {
	"AboutUs": "aboutUs_AboutUs__2aY9A"
};
module.exports = ___CSS_LOADER_EXPORT___;


/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vY29tcG9uZW50cy9hYm91dFVzLm1vZHVsZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7OztBQUFBO0FBQ0Esa0NBQWtDLG1CQUFPLENBQUMscUdBQWdEO0FBQzFGO0FBQ0E7QUFDQSw4QkFBOEIsUUFBUyw0QkFBNEIsZ0JBQWdCLHFCQUFxQix5QkFBeUIsR0FBRywrQkFBK0IsaUNBQWlDLHVCQUF1Qix3QkFBd0IsS0FBSyxHQUFHLE9BQU8sb0ZBQW9GLFVBQVUsV0FBVyxXQUFXLE1BQU0sS0FBSyxLQUFLLFdBQVcsV0FBVyxLQUFLLG1DQUFtQyxvQkFBb0IseUJBQXlCLDZCQUE2QixLQUFLLDZCQUE2QixzQkFBc0IsNkJBQTZCLDhCQUE4QixTQUFTLEtBQUssdUJBQXVCO0FBQ3RxQjtBQUNBO0FBQ0E7QUFDQTtBQUNBIiwiZmlsZSI6InN0YXRpYy93ZWJwYWNrL3BhZ2VzL2luZGV4LjgyMjg5MGE0N2VhN2UyN2Y0YzM1LmhvdC11cGRhdGUuanMiLCJzb3VyY2VzQ29udGVudCI6WyIvLyBJbXBvcnRzXG52YXIgX19fQ1NTX0xPQURFUl9BUElfSU1QT1JUX19fID0gcmVxdWlyZShcIi4uL25vZGVfbW9kdWxlcy9jc3MtbG9hZGVyL2Rpc3QvcnVudGltZS9hcGkuanNcIik7XG52YXIgX19fQ1NTX0xPQURFUl9FWFBPUlRfX18gPSBfX19DU1NfTE9BREVSX0FQSV9JTVBPUlRfX18odHJ1ZSk7XG4vLyBNb2R1bGVcbl9fX0NTU19MT0FERVJfRVhQT1JUX19fLnB1c2goW21vZHVsZS5pZCwgXCIuYWJvdXRVc19BYm91dFVzX18yYVk5QSB7XFxuICB3aWR0aDogMTAwJTtcXG4gIG92ZXJmbG93OiBoaWRkZW47XFxuICBmaWx0ZXI6IGdyYXlzY2FsZSgxKTtcXG59XFxuXFxuQG1lZGlhIChtaW4td2lkdGg6IDc2OHB4KSB7XFxuICAuYWJvdXRVc19BYm91dFVzX18yYVk5QSBpbWcge1xcbiAgICBtaW4td2lkdGg6IDU4NHB4O1xcbiAgICBtaW4taGVpZ2h0OiA0NzBweDtcXG4gIH1cXG59XCIsIFwiXCIse1widmVyc2lvblwiOjMsXCJzb3VyY2VzXCI6W1wid2VicGFjazovL2Fib3V0VXMubW9kdWxlLnNjc3NcIl0sXCJuYW1lc1wiOltdLFwibWFwcGluZ3NcIjpcIkFBQUE7RUFDSSxXQUFBO0VBQ0EsZ0JBQUE7RUFDQSxvQkFBQTtBQUNKOztBQUNBO0VBQ0k7SUFDSSxnQkFBQTtJQUNBLGlCQUFBO0VBRU47QUFDRlwiLFwic291cmNlc0NvbnRlbnRcIjpbXCIuQWJvdXRVcyB7XFxyXFxuICAgIHdpZHRoOiAxMDAlO1xcclxcbiAgICBvdmVyZmxvdzogaGlkZGVuO1xcclxcbiAgICBmaWx0ZXI6IGdyYXlzY2FsZSgxKTtcXHJcXG59XFxyXFxuQG1lZGlhKG1pbi13aWR0aDo3NjhweCkge1xcclxcbiAgICAuQWJvdXRVcyBpbWcge1xcclxcbiAgICAgICAgbWluLXdpZHRoOiA1ODRweDtcXHJcXG4gICAgICAgIG1pbi1oZWlnaHQ6IDQ3MHB4O1xcclxcbiAgICB9XFxyXFxufVxcclxcblwiXSxcInNvdXJjZVJvb3RcIjpcIlwifV0pO1xuLy8gRXhwb3J0c1xuX19fQ1NTX0xPQURFUl9FWFBPUlRfX18ubG9jYWxzID0ge1xuXHRcIkFib3V0VXNcIjogXCJhYm91dFVzX0Fib3V0VXNfXzJhWTlBXCJcbn07XG5tb2R1bGUuZXhwb3J0cyA9IF9fX0NTU19MT0FERVJfRVhQT1JUX19fO1xuIl0sInNvdXJjZVJvb3QiOiIifQ==