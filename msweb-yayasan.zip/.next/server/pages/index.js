module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = require('../ssr-module-cache.js');
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		var threw = true;
/******/ 		try {
/******/ 			modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 			threw = false;
/******/ 		} finally {
/******/ 			if(threw) delete installedModules[moduleId];
/******/ 		}
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 4);
/******/ })
/************************************************************************/
/******/ ({

/***/ "1nPM":
/***/ (function(module, exports) {

// Exports
module.exports = {
	"AboutUs": "aboutUs_AboutUs__2aY9A"
};


/***/ }),

/***/ 4:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("RNiq");


/***/ }),

/***/ "4Q3z":
/***/ (function(module, exports) {

module.exports = require("next/router");

/***/ }),

/***/ "F5FC":
/***/ (function(module, exports) {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ "K7k0":
/***/ (function(module, exports) {



/***/ }),

/***/ "MHAL":
/***/ (function(module, exports) {

module.exports = require("react-youtube-embed");

/***/ }),

/***/ "No/t":
/***/ (function(module, exports) {

module.exports = require("@fortawesome/free-solid-svg-icons");

/***/ }),

/***/ "O/hg":
/***/ (function(module, exports) {

module.exports = require("react-slick");

/***/ }),

/***/ "RNiq":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, "getServerSideProps", function() { return /* binding */ getServerSideProps; });

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__("F5FC");

// EXTERNAL MODULE: ./components/news.module.scss
var news_module = __webpack_require__("rVe0");
var news_module_default = /*#__PURE__*/__webpack_require__.n(news_module);

// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__("4Q3z");

// CONCATENATED MODULE: ./components/news.js



 // import Link from 'next/link'

function News({
  news
}) {
  const router = Object(router_["useRouter"])();
  return /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
    className: "bg-gray-200 lg:px-12 py-8",
    children: [/*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
      className: "max-w-screen-xl mx-auto px-4 sm:px-6 lg:px-8 lg:text-center",
      children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("h3", {
        className: "mt-2 text-3xl tracking-wide leading-8 font-extrabold tracking-tight text-gray-900 sm:text-4xl sm:leading-10",
        children: "Berita Terbaru"
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("p", {
        className: "my-4 max-w-2xl font-light text-lg leading-7 text-black-500 opacity-75 lg:mx-auto",
        children: "Simak berita yang menarik, bermanfaat dan seputar kegiatan santri."
      })]
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
      className: "flex flex-wrap justify-center lg:justify-between lg:mb-4",
      children: news.length > 1 ? news // .sort((a, b) => {     return new Date(b.tanggal_berita) - new
      // Date(a.tanggal_berita); })     .slice(0, 6)
      .map(item => {
        let isi = item.content.rendered;
        let title = item.title.rendered;

        if (title.length > 40) {
          title = title.substr(0, 40) + '[...]';
        }

        if (isi.length > 100) {
          isi = isi.substr(0, 100) + '[...]';
        }

        let datePart = item.date.match(/\d+/g),
            monthInd = ["", "Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"],
            year = datePart[0],
            month = parseInt(datePart[1]),
            newMonth = monthInd[month],
            day = datePart[2];
        let ValueTgl = day + '/' + newMonth + '/' + year;
        return /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
          className: news_module_default.a.wrapper,
          children: [/*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
            className: news_module_default.a.imgWrap,
            children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("img", {
              src: `${item.featured_image.size_full}`,
              alt: "afwan tidak ada thumbnail :)"
            }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("p", {
              className: news_module_default.a.date,
              children: ValueTgl
            })]
          }), /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
            className: news_module_default.a.body,
            children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("p", {
              className: "text-md mb-1 leading-6 text-indigo-600 font-semibold tracking-wide uppercase",
              children: item.category.map(name => {
                return name.name;
              }).join("/")
            }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("p", {
              className: news_module_default.a.title,
              children: title
            }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
              className: news_module_default.a.desc,
              dangerouslySetInnerHTML: {
                __html: isi
              }
            }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("button", {
              className: news_module_default.a.btnDetails,
              onClick: () => router.push({
                asPath: 'post/id',
                pathname: `post/${item.slug}`
              }),
              children: "Lihat selengkapnya"
            })]
          })]
        }, item.id);
      }) : /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
        className: "mx-auto",
        children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("p", {
          className: "my-4 max-w-2xl font-light text-lg text-center leading-7 text-red-500 opacity-75 lg:mx-auto",
          children: "Mohon maaf gagal memuat berita, cek koneksi anda terlebih dahulu kemudian refresh halaman."
        })
      })
    })]
  });
}

/* harmony default export */ var components_news = (News);
// EXTERNAL MODULE: external "@fortawesome/react-fontawesome"
var react_fontawesome_ = __webpack_require__("uhWA");

// EXTERNAL MODULE: external "@fortawesome/free-solid-svg-icons"
var free_solid_svg_icons_ = __webpack_require__("No/t");

// CONCATENATED MODULE: ./components/excellence.js





function Excellence() {
  return /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
    className: "py-12 bg-white",
    children: /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
      className: "max-w-screen-xl mx-auto px-4 sm:px-6 lg:px-8",
      children: [/*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
        className: "lg:text-center",
        children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("p", {
          className: "text-md leading-6 text-indigo-600 font-semibold tracking-wide uppercase",
          children: "School Of Huffadz"
        }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("h3", {
          className: "mt-2 text-3xl tracking-wide leading-8 font-extrabold tracking-tight text-gray-900 sm:text-4xl sm:leading-10",
          children: "Ma'rifatussalaam Quranic Boarding School"
        }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("p", {
          className: "mt-4 max-w-2xl  font-light text-lg leading-6 text-gray-500 lg:mx-auto tracking-wide",
          children: "Berikut alasan mengapa harus memilih SMP AL-Qur'an Ma'rifatussalaam Quranic Boarding School."
        })]
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
        className: "mt-10",
        children: /*#__PURE__*/Object(jsx_runtime_["jsxs"])("ul", {
          className: "md:grid md:grid-cols-2 md:gap-x-8 md:gap-y-10",
          children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("li", {
            children: /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
              className: "flex",
              children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
                className: "flex-shrink-0",
                children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
                  className: "flex items-center justify-center h-12 w-12 rounded-md bg-indigo-500 text-white",
                  children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(react_fontawesome_["FontAwesomeIcon"], {
                    icon: free_solid_svg_icons_["faStarAndCrescent"],
                    size: "lg"
                  })
                })
              }), /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
                className: "ml-4",
                children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("h4", {
                  className: "text-lg leading-6 tracking-wide font-medium text-gray-900",
                  children: "Kurikulum"
                }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("p", {
                  className: "mt-2 text-lg leading-6 tracking-wide font-light text-gray-500",
                  children: "Ma'rifatussalaam memiliki kurikulum khas yang dirancang dan di persiapkan oleh tenaga kependidikan yang bermutu jenjang pendidikan menengah, sehingga dapat berkontribusi dalam mempersiapkan generasi yang tangguh di masa depan.."
                })]
              })]
            })
          }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("li", {
            className: "mt-10 md:mt-0",
            children: /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
              className: "flex",
              children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
                className: "flex-shrink-0",
                children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
                  className: "flex items-center justify-center h-12 w-12 rounded-md bg-indigo-500 text-white",
                  children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(react_fontawesome_["FontAwesomeIcon"], {
                    icon: free_solid_svg_icons_["faMapMarkerAlt"],
                    size: "lg"
                  })
                })
              }), /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
                className: "ml-4",
                children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("h4", {
                  className: "text-lg leading-6 tracking-wide font-medium text-gray-900",
                  children: "Lokasi Strategis"
                }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("p", {
                  className: "mt-2 text-lg leading-6 tracking-wide font-light text-gray-500",
                  children: "Terletak di jalan manyeti Subang-Kalijati dan dekat dengan pintu tol Subang menjadikan Ma'rifatussalaam Qur'anic Boarding School sangat mudah dijangkau."
                })]
              })]
            })
          }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("li", {
            className: "mt-10 md:mt-0",
            children: /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
              className: "flex",
              children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
                className: "flex-shrink-0",
                children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
                  className: "flex items-center justify-center h-12 w-12 rounded-md bg-indigo-500 text-white",
                  children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(react_fontawesome_["FontAwesomeIcon"], {
                    icon: free_solid_svg_icons_["faBuilding"],
                    size: "lg"
                  })
                })
              }), /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
                className: "ml-4",
                children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("h4", {
                  className: "text-lg leading-6 tracking-wide font-medium text-gray-900",
                  children: "Fasilitas"
                }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("p", {
                  className: "mt-2 text-lg leading-6 tracking-wide font-light text-gray-500",
                  children: "Infrastruktur dan fasilitas yang memadai dengan investasi pendidikan yang terjangkau, pemisahan asrama dan kelas terpisah antara ikhwan dan akhwat."
                })]
              })]
            })
          }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("li", {
            className: "mt-10 md:mt-0",
            children: /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
              className: "flex",
              children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
                className: "flex-shrink-0",
                children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
                  className: "flex items-center justify-center h-12 w-12 rounded-md bg-indigo-500 text-white",
                  children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(react_fontawesome_["FontAwesomeIcon"], {
                    icon: free_solid_svg_icons_["faBuilding"],
                    size: "lg"
                  })
                })
              }), /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
                className: "ml-4",
                children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("h4", {
                  className: "text-lg leading-6 tracking-wide font-medium text-gray-900",
                  children: "Lingkungan Heterogen"
                }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("p", {
                  className: "mt-2 text-lg leading-6 tracking-wide font-light text-gray-500",
                  children: "lingkungan sosial yang heterogen dikarenakan santri SMP AL-Quran Ma'rifatussalaam berasal dari berbagai daerah di tanah air."
                })]
              })]
            })
          }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("li", {
            className: "mt-10 md:mt-0",
            children: /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
              className: "flex",
              children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
                className: "flex-shrink-0",
                children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
                  className: "flex items-center justify-center h-12 w-12 rounded-md bg-indigo-500 text-white",
                  children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(react_fontawesome_["FontAwesomeIcon"], {
                    icon: free_solid_svg_icons_["faUserAlt"],
                    size: "lg"
                  })
                })
              }), /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
                className: "ml-4",
                children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("h4", {
                  className: "text-lg leading-6 tracking-wide font-medium text-gray-900",
                  children: "SDM Profesional"
                }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("p", {
                  className: "mt-2 text-lg leading-6 tracking-wide font-light text-gray-500",
                  children: "Memiliki SDM pendidik dan tenaga kependidikan yang terseleksi dengan rata-rata berusia muda."
                })]
              })]
            })
          }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("li", {
            className: "mt-10 md:mt-0",
            children: /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
              className: "flex",
              children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
                className: "flex-shrink-0",
                children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
                  className: "flex items-center justify-center h-12 w-12 rounded-md bg-indigo-500 text-white",
                  children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(react_fontawesome_["FontAwesomeIcon"], {
                    icon: free_solid_svg_icons_["faGraduationCap"],
                    size: "lg"
                  })
                })
              }), /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
                className: "ml-4",
                children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("h4", {
                  className: "text-lg leading-6 tracking-wide font-medium text-gray-900",
                  children: "Daya Serap Tingi"
                }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("p", {
                  className: "mt-2 text-lg leading-6 tracking-wide font-light text-gray-500",
                  children: "Alumni SMP AL-Qur'an Ma'rifatussalaam tersebar di SMA,SMAIT, Pondok Pesantren favorit."
                })]
              })]
            })
          })]
        })
      })]
    })
  });
}

/* harmony default export */ var excellence = (Excellence);
// EXTERNAL MODULE: external "react-slick"
var external_react_slick_ = __webpack_require__("O/hg");
var external_react_slick_default = /*#__PURE__*/__webpack_require__.n(external_react_slick_);

// EXTERNAL MODULE: ./components/banner.module.scss
var banner_module = __webpack_require__("dS9e");
var banner_module_default = /*#__PURE__*/__webpack_require__.n(banner_module);

// EXTERNAL MODULE: ./node_modules/slick-carousel/slick/slick.css
var slick = __webpack_require__("tyWD");

// EXTERNAL MODULE: ./node_modules/slick-carousel/slick/slick-theme.css
var slick_theme = __webpack_require__("K7k0");

// CONCATENATED MODULE: ./components/banner.js


function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }






function Banner() {
  const settings = {
    dots: false,
    lazyLoad: true,
    infinite: true,
    speed: 1000,
    autoplay: true,
    autoplaySpeed: 8000,
    slidesToShow: 1,
    slidesToScroll: 1
  };
  const image = [{
    src: "https://psb.marifatussalaam.org/assets/frontend/image/header2.png"
  }, {
    src: "https://psb.marifatussalaam.org/assets/frontend/image/header3.png"
  }];

  const handleClickDaftar = () => {
    window.open('https://psb.marifatussalaam.org', '_blank');
  };

  return /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
    className: banner_module_default.a.container,
    children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(external_react_slick_default.a, _objectSpread(_objectSpread({}, settings), {}, {
      children: image.map((i, x) => /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
        children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("img", {
          src: i.src,
          alt: "none",
          onClick: handleClickDaftar
        })
      }, x))
    }))
  });
}

/* harmony default export */ var banner = (Banner);
// EXTERNAL MODULE: ./components/aboutUs.module.scss
var aboutUs_module = __webpack_require__("1nPM");
var aboutUs_module_default = /*#__PURE__*/__webpack_require__.n(aboutUs_module);

// CONCATENATED MODULE: ./components/aboutUs.js


 // import Image from 'next/image'

function AboutUs() {
  return /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
    className: "py-8 lg:py-12 bg-white",
    children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
      className: "max-w-screen-xl mx-auto px-4 sm:px-6 lg:px-8",
      children: /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
        className: "grid lg:grid-cols-2 gap-4 ",
        children: [/*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
          children: [/*#__PURE__*/Object(jsx_runtime_["jsxs"])("h3", {
            className: "text-3xl tracking-wide font-extrabold text-gray-900 sm:text-4xl leading-9 lg:leading-relaxed",
            children: ["Selamat Datang di", /*#__PURE__*/Object(jsx_runtime_["jsx"])("br", {}), "SMP Al-Qur'an Ma'rifatussalaam"]
          }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("p", {
            className: "mt-1 text-md leading-6 text-indigo-600 font-semibold tracking-wide uppercase",
            children: "Qur'anic Boarding School"
          }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("p", {
            className: "mt-4 text-lg text-opacity-75 tracking-wide leading-relaxed text-gray-900",
            children: "SMP Al-Qur'an Ma'rifatussalaam Qur'anic Boarding School berlokasi di Jl. Manyeti No.6 RT 05/01 Kp.Cikadu Desa Manyeti, Kec. Dawuan, Kab. Subang, Provinsi Jawa Barat. Ma'rifatussalaam memiliki kurikulum khas yang dirancang dan di persiapkan oleh tenaga kependidikan yang bermutu jenjang pendidikan menengah, sehingga dapat berkontribusi dalam mempersiapkan generasi yang tangguh di masa depan, menghasilkan intelektual muslim yang mampu membangun dan memakmurkan bangsa, yang akan ikut berkontribusi mewujudkan indonesia emas 2045."
          }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("p", {
            className: "pt-4 text-lg text-opacity-75 tracking-wide leading-relaxed text-gray-900",
            children: "SMP Al-Qur\u2019an Ma\u2019rifatussalaam merupakan program unggulan Pesantren Tahfizhul Qur\u2019an Ma\u2019rifatussalaam dengan target 3 tahun hafal 20 juz. Adapun kurikulum yang diterapkan adalah kurikulum nasional dan kurikulum kepesantrenan yang berbasis pada pembetukkan karakter (character building)."
          })]
        }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
          className: aboutUs_module_default.a.AboutUs,
          children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("img", {
            src: "/pmb.png",
            alt: "picture of the author"
          })
        })]
      })
    })
  });
}

/* harmony default export */ var aboutUs = (AboutUs);
// EXTERNAL MODULE: external "react-youtube-embed"
var external_react_youtube_embed_ = __webpack_require__("MHAL");
var external_react_youtube_embed_default = /*#__PURE__*/__webpack_require__.n(external_react_youtube_embed_);

// CONCATENATED MODULE: ./components/videoProfile.js




function VideProfile() {
  return /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
    className: "bg-gray-200 lg:px-12 py-5",
    children: [/*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
      className: "max-w-screen-xl mx-auto px-4 sm:px-6 lg:px-8 lg:text-center",
      children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("h3", {
        className: "mt-2 text-3xl tracking-wide leading-8 font-extrabold tracking-tight text-gray-900 sm:text-4xl sm:leading-10",
        children: "Video Profile"
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("p", {
        className: "my-4 max-w-2xl font-light text-lg leading-7 text-black-500 opacity-75 lg:mx-auto",
        children: "Video Profile Ma'rifatussalaam Qur'anic Boarding School."
      })]
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
      className: "flex justify-center mb-8",
      children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
        className: "w-full lg:w-3/4",
        children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(external_react_youtube_embed_default.a, {
          id: "https://youtu.be/yIlxK8-Kozo"
        })
      })
    })]
  });
}

/* harmony default export */ var videoProfile = (VideProfile);
// EXTERNAL MODULE: ./components/testimoni.module.scss
var testimoni_module = __webpack_require__("pUR/");
var testimoni_module_default = /*#__PURE__*/__webpack_require__.n(testimoni_module);

// CONCATENATED MODULE: ./components/testimoni.child.js



function testimoni_child_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function testimoni_child_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { testimoni_child_ownKeys(Object(source), true).forEach(function (key) { testimoni_child_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { testimoni_child_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function testimoni_child_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }






function TestimoniSLider() {
  const settings = {
    dots: false,
    arrows: false,
    lazyLoad: true,
    infinite: true,
    speed: 1000,
    autoplay: true,
    autoplaySpeed: 5000,
    swipeToSlide: false,
    touchMove: true,
    swipe: true,
    slidesToShow: 2,
    slidesToScroll: 2,
    responsive: [{
      breakpoint: 600,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1
      }
    }]
  };
  const testimoni = [{
    name: "Faiza Shabrina Robbani",
    image: "/framfaiza.jpg",
    testi: "Ma'rifatussalaam adalah tempat di mana kemandirian dan kesederhanaan di bentuk. " + "Selama tiga tahun saya bersekolah di sana, banyak pengalaman dengan segudang hik" + "mah yang membekas pada diri saya dan dapat menjadi bekal dalam menjalani  kehidu" + "pan. Itu semua tidak terlepas dari peran asatidz yang telah membimbing dengan ik" + "hlas, juga teman-teman yang saling menguatkan.",
    degree: "Santri Angkatan 3"
  }, {
    name: " Salma Alifah Salsabila",
    image: "/framsalma.jpg",
    testi: "Bagi saya bersekolah di Ma'rifatussalaam adalah suatu pengalaman yang sangat ber" + "harga.Banyak pelajaran yang dapat saya ambil,salah satunya adalah sifat saling m" + "enghargai dan juga melengkapi satu sama lain.Dan saya juga ingin berterimakasih " + "kepada para asatidz yang telah membimbing dengan sepenuh hati.Harapan kedepannya" + " semoga Ma'rifatussalaam bisa menjadi sekolah unggulan dalam bidang Ahklak maupu" + "n Akademik.",
    degree: "Santri Angkatan 3"
  }, {
    name: "M. Zacky Irham",
    image: "/framzaki.jpg",
    testi: "Alhamdulillah sebagai lulusan alumni SMPQ Ma'rifatussalaam. menurut saya lingkun" + "gan untuk menambah ilmu dan menghafal al-quran sangatlah kondusif karna di bantu" + "nya bimbingan dari ustad dan ustadzah menjadikan pembelajaran lebih efektif.",
    degree: "Santri Angkatan 3"
  }];
  return /*#__PURE__*/Object(jsx_runtime_["jsx"])(external_react_slick_default.a, testimoni_child_objectSpread(testimoni_child_objectSpread({}, settings), {}, {
    children: testimoni.map((res, index) => /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
      className: testimoni_module_default.a.wrapper + " block bg-white rounded-xl p-8 md:p-0",
      children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
        className: testimoni_module_default.a.image,
        children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("img", {
          className: "w-32 h-32 md:w-20 md:h-20 md:rounded-none rounded-full mx-auto",
          src: res.image,
          alt: res.image,
          width: "384",
          height: "512"
        })
      }), /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
        className: "pt-6 md:p-8 text-center md:text-left space-y-4",
        children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
          children: /*#__PURE__*/Object(jsx_runtime_["jsxs"])("p", {
            className: "p-4 mt-4 text-base text-opacity-75 tracking-wide leading-relaxed text-gray-900 bg-gray-100",
            children: ["\u201C", res.testi, "\u201D"]
          })
        }), /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
          className: "pl-4 font-medium",
          children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
            className: "text-md leading-6 text-indigo-600 font-semibold tracking-wide",
            children: res.name
          }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
            className: "text-gray-500",
            children: res.degree
          })]
        })]
      })]
    }, index))
  }));
}

/* harmony default export */ var testimoni_child = (TestimoniSLider);
// CONCATENATED MODULE: ./components/testimoni.js




function Testimoni() {
  return /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
    className: "bg-white lg:px-12",
    children: [/*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
      className: "max-w-screen-xl mx-auto px-4 sm:px-6 lg:px-8 lg:text-center",
      children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("h3", {
        className: "mt-2 text-3xl tracking-wide leading-8 font-extrabold tracking-tight text-gray-900 sm:text-4xl sm:leading-10",
        children: "Testimoni Santri"
      }), /*#__PURE__*/Object(jsx_runtime_["jsxs"])("p", {
        className: "mt-4 max-w-2xl  font-light text-lg leading-6 text-gray-500 lg:mx-auto tracking-wide",
        children: ["Apa kata santri lulusan SMP AL-Qur'an Ma'rifatussalaam ", /*#__PURE__*/Object(jsx_runtime_["jsx"])("br", {}), "  Quranic Boarding School"]
      })]
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])(testimoni_child, {})]
  });
}

/* harmony default export */ var components_testimoni = (Testimoni);
// CONCATENATED MODULE: ./pages/index.js







 // import Search from '../components/searchList'

function Home({
  posts
}) {
  return /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
    children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])(banner, {}), /*#__PURE__*/Object(jsx_runtime_["jsx"])(aboutUs, {}), /*#__PURE__*/Object(jsx_runtime_["jsx"])(components_news, {
      news: posts
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])(excellence, {}), /*#__PURE__*/Object(jsx_runtime_["jsx"])(components_testimoni, {})]
  });
}

async function getServerSideProps(context) {
  const res = await fetch(`https://adminwp.marifatussalaam.org/wp-json/wp/v2/posts?per_page=3`);
  const data = await res.json();
  const posts = data;
  return {
    props: {
      posts
    } // will be passed to the page component as props

  };
}
/* harmony default export */ var pages = __webpack_exports__["default"] = (Home);

/***/ }),

/***/ "dS9e":
/***/ (function(module, exports) {

// Exports
module.exports = {
	"container": "banner_container__1VYlZ"
};


/***/ }),

/***/ "pUR/":
/***/ (function(module, exports) {

// Exports
module.exports = {
	"image": "testimoni_image__1eD3F",
	"wrapper": "testimoni_wrapper__q1utH"
};


/***/ }),

/***/ "rVe0":
/***/ (function(module, exports) {

// Exports
module.exports = {
	"wrapper": "news_wrapper__FHCnv",
	"imgWrap": "news_imgWrap__2QQMw",
	"date": "news_date__2JBa_",
	"body": "news_body__1_iOg",
	"title": "news_title__1vPv9",
	"desc": "news_desc__-IBK-",
	"btnDetails": "news_btnDetails__3GSLx"
};


/***/ }),

/***/ "tyWD":
/***/ (function(module, exports) {



/***/ }),

/***/ "uhWA":
/***/ (function(module, exports) {

module.exports = require("@fortawesome/react-fontawesome");

/***/ })

/******/ });