import style from './footer.module.scss'

function Footer() {
    return(
        
        <div className={style.footer}>
            <p> &copy; SMP AL-Qur'an Ma'rifatussalaam </p>
        </div>
    )
}

export default Footer