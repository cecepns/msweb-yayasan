module.exports = {
    images: {
      domains: ['https://adminwp.marifatussalaam.org/'],
      domains: ['https://marifatussalaam.org/'],
    },
  }